### Problem description

<!--Briefly describe the problem that you found.
    Only DOCUMENTATION issues should be filed here.
    For general questions, go to https://forums.docker.com/. -->

### Problem location

<!-- Help us find the problem quickly by choosing one of these. -->

- I saw a problem on the following URL: <URL>

- I couldn't find the information I wanted. I expected to find it near the following URL: <URL>

- Other: <DETAILS>

### Project version(s) affected

<!-- If this problem only affects specific versions of a project (like Docker
     Engine 1.13), tell us here. The fix may need to take that into account. -->

### Suggestions for a fix

<!--If you have specific ideas about how we can fix this, let us know. -->


<!-- To improve this template, edit the .github/ISSUE_TEMPLATE.md file -->
