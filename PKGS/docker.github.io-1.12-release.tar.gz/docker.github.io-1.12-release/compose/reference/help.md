---
description: docker-compose help
keywords: fig, composition, compose, docker, orchestration, cli, help
title: docker-compose help
---

```
Usage: help COMMAND
```

Displays help and usage instructions for a command.