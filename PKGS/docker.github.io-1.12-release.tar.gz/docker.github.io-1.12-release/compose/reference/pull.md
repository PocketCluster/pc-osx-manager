---
description: Pulls service images.
keywords: fig, composition, compose, docker, orchestration, cli,  pull
title: docker-compose pull
---

```
Usage: pull [options] [SERVICE...]

Options:
--ignore-pull-failures  Pull what it can and ignores images with pull failures.
```

Pulls service images.