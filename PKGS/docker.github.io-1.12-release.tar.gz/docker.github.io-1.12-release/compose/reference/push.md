---
description: Pushes service images.
keywords: fig, composition, compose, docker, orchestration, cli,  push
title: docker-compose push
---

```
Usage: push [options] [SERVICE...]

Options:
    --ignore-push-failures  Push what it can and ignores images with push failures.
```

Pushes images for services.