---
description: Starts existing containers for a service.
keywords: fig, composition, compose, docker, orchestration, cli,  start
title: docker-compose start
---

```
Usage: start [SERVICE...]
```

Starts existing containers for a service.