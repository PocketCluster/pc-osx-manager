---
description: Unpauses paused containers for a service.
keywords: fig, composition, compose, docker, orchestration, cli, unpause
title: docker-compose unpause
---

```
Usage: unpause [SERVICE...]
```

Unpauses paused containers of a service.