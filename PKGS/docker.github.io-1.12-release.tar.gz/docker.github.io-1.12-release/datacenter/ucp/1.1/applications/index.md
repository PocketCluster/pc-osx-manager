---
description: Learn how to manage applications on  Docker Universal Control Plane.
keywords: docker, ucp, apps, management
title: UCP applications
---

This section includes the following topics:

* [Deploy an app from the UI](deploy-app-ui.md)
* [Deploy an app from the CLI](deploy-app-cli.md)