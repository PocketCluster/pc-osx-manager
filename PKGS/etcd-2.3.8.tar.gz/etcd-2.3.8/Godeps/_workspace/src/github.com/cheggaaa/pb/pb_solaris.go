// +build solaris

package pb

const sys_ioctl = 54
