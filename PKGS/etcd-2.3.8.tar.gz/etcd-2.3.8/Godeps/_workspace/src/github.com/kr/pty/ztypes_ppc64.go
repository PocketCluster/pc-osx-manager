// +build ppc64

// Created by cgo -godefs - DO NOT EDIT
// cgo -godefs types.go

package pty

type (
	_C_int  int32
	_C_uint uint32
)
