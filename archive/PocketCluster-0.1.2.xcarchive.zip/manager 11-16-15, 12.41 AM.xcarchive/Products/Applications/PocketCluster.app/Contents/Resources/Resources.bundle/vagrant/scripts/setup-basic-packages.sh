#!/usr/bin/env bash

# salt-stack
echo "deb http://ppa.launchpad.net/saltstack/salt/ubuntu `lsb_release -sc` main" | tee /etc/apt/sources.list.d/saltstack.list
wget -q -O- "http://keyserver.ubuntu.com:11371/pks/lookup?op=get&search=0x4759FA960E27C0A6" | apt-key add -

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get -y install salt-minion
